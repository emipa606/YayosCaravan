﻿using UnityEngine;
using Verse;
using RimWorld;
using HugsLib;
using HugsLib.Settings;
using System.Linq;
using RimWorld.Planet;
using System.Collections.Generic;
using HarmonyLib;
using System;
using System.Reflection;
using Verse.Noise;
using System.Collections;


namespace caravanVisual
{

    public class core : ModBase
    {
        public override string ModIdentifier => "caravanVisual";

        private SettingHandle<bool> val_swingAni_s;
        public static bool val_swingAni;

        public enum en_zoomMode { none, bigLeader, vanilla}
        private SettingHandle<en_zoomMode> val_zoomMode_s;
        public static en_zoomMode val_zoomMode;

        private SettingHandle<bool> val_showAnimal_s;
        public static bool val_showAnimal;

        private SettingHandle<int> val_limitCount_s;
        public static int val_limitCount;

        private SettingHandle<float> val_scale_s;
        public static float val_scale;

        private SettingHandle<float> val_zoomScale_s;
        public static float val_zoomScale;

        private SettingHandle<float> val_space_s;
        public static float val_space;

        



        public override void DefsLoaded()
        {
            val_swingAni_s = Settings.GetHandle<bool>("val_swingAni", "swing animation", "swing animation", true);
            val_zoomMode_s = Settings.GetHandle<en_zoomMode>("val_zoomMode", "zoom out mode", "Sets how the caravan is displayed when viewed from a distance by zooming out.", en_zoomMode.bigLeader);
            val_showAnimal_s = Settings.GetHandle<bool>("val_showAnimal", "show animal", "show animal", true);
            val_limitCount_s = Settings.GetHandle<int>("val_limitCount", "max pawn count", "Maximum number of pawns to display in one caravan\n\n-1 or 0 is infinity", -1);
            val_scale_s = Settings.GetHandle<float>("val_scale", "pawn scale", "scale of pawns", 1f);
            val_zoomScale_s = Settings.GetHandle<float>("val_zoomScale", "pawn zoomOut scale", "scale of pawns when zoom out", 1f);
            val_space_s = Settings.GetHandle<float>("val_space", "spacing between pawns", "spacing between pawns", 1f);


            //WorldObjectDefOf.Caravan.expandingIcon = false;

            SettingsChanged();
        }
        

        public override void SettingsChanged()
        {
            val_swingAni = val_swingAni_s.Value;
            val_zoomMode = val_zoomMode_s.Value;
            val_showAnimal = val_showAnimal_s.Value;

            val_limitCount_s.Value = Mathf.Clamp(val_limitCount_s.Value, -1, 999);
            val_limitCount = val_limitCount_s.Value;

            val_scale_s.Value = Mathf.Clamp(val_scale_s.Value, 0.01f, 1000f);
            val_scale = val_scale_s.Value;

            val_zoomScale_s.Value = Mathf.Clamp(val_zoomScale_s.Value, 0.01f, 1000f);
            val_zoomScale = val_zoomScale_s.Value;

            val_space_s.Value = Mathf.Clamp(val_space_s.Value, 0.01f, 1000f);
            val_space = val_space_s.Value * val_scale_s.Value;

        }

        public override void WorldLoaded()
        {
            dataUtility.reset();
        }


        caravanData cd;
        public override void Tick(int currentTick)
        {
            if (!WorldRendererUtility.WorldRenderedNow)
            {
                foreach (Caravan c in dataUtility.dic_caravan.Keys)
                {
                    if (c == null)
                    {
                        dataUtility.Remove(c);
                        continue;
                    }
                    cd = dataUtility.GetData(c);
                    cd.tryAddPrevPos();
                }
            }
        }





        public static Rot4 getRot(Caravan caravan)
        {
            Vector3 vel = caravan.tweener.LastTickTweenedVelocity;
            Rot4 r = Rot4.South;
            if (Mathf.Abs(vel.x) > Mathf.Abs(vel.y))
            {
                r = vel.x >= 0 ? Rot4.East : Rot4.West;
            }
            else
            {
                r = vel.y > 0 ? Rot4.North : Rot4.South;
            }

            return r;
        }

        public static Rot4 getRot(Vector3 vel)
        {
            Rot4 r = Rot4.South;
            if (Mathf.Abs(vel.x) > Mathf.Abs(vel.y))
            {
                r = vel.x >= 0 ? Rot4.East : Rot4.West;
            }
            else
            {
                r = vel.y > 0 ? Rot4.North : Rot4.South;
            }

            return r;
        }

        static public float time = 0;
        public override void Update()
        {
            if (Current.ProgramState != ProgramState.Playing) return;
            if (!Find.TickManager.Paused) time += Time.deltaTime;
            if (time > 1000f) time = 0f;
        }


        public static void DrawQuadTangentialToPlanet(int uniqueTick, Vector3 pos, float size, float altOffset, Material material, bool counterClockwise = false, bool useSkyboxLayer = false, MaterialPropertyBlock propertyBlock = null)
		{
			if (material == null) return;
            Vector3 normalized = pos.normalized;
			Vector3 vector = ((!counterClockwise) ? normalized : (-normalized));
            Vector3 angle = Vector3.left;


            if (val_swingAni)
            {
                if (uniqueTick >= 0)
                {
                    float wiggle = Mathf.Sin((time + uniqueTick) * 5f);
                    angle += (Vector3.up * wiggle * 0.1f);
                    pos += wiggle * new Vector3(0.03f, 0f, 0f);
                    angle.Normalize();
                }
                else
                {
                    float wiggle = Mathf.Sin((time + uniqueTick) * 2f);
                    angle += (Vector3.up * wiggle * 0.05f);
                    pos += wiggle * new Vector3(0.015f, 0f, 0f);
                    angle.Normalize();
                }
            }
            

            Quaternion q = Quaternion.LookRotation(Vector3.Cross(vector, angle), vector);
            
			Vector3 s = new Vector3(size, 1f, size);
			Matrix4x4 matrix = default(Matrix4x4);
			matrix.SetTRS(pos + normalized * altOffset, q, s);

            int layer = (useSkyboxLayer ? WorldCameraManager.WorldSkyboxLayer : WorldCameraManager.WorldLayer);
			if (propertyBlock != null)
			{

                Graphics.DrawMesh(MeshPool.plane10, matrix, material, layer, null, 0, propertyBlock);
			}
			else
			{
				Graphics.DrawMesh(MeshPool.plane10, matrix, material, layer);
			}
		}



    }










}