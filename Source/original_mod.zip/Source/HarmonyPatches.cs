﻿using System;
using System.Reflection;
using HarmonyLib;
using Verse;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using System.Collections.Generic;
using Verse.AI.Group;
using System.Linq;

namespace caravanVisual
{


    public class HarmonyPatches : Mod
    {

        public HarmonyPatches(ModContentPack content) : base(content)
        {
            var harmony = new Harmony("com.yayo.caravanVisual");
            harmony.PatchAll(Assembly.GetExecutingAssembly());

        }

    }

    [HarmonyPatch(typeof(Caravan))]
    [HarmonyPatch("ExposeData")]
    public class Patch_Caravan_ExposeData
    {
        private static void Postfix(Caravan __instance)
        {
            dataUtility.GetData(__instance).ExposeData();
        }
    }





    

    // 줌인 드로우

    [HarmonyPatch(typeof(WorldObject), "Draw")]
    public class Patch_StatPart_WorldObject_Draw
    {
        //private static MaterialPropertyBlock propertyBlock = AccessTools.StaticFieldRefAccess<MaterialPropertyBlock>(AccessTools.Field(typeof(WorldObject), "propertyBlock")).Invoke();
        static MaterialPropertyBlock propertyBlock0 = new MaterialPropertyBlock();
        static MaterialPropertyBlock propertyBlock = new MaterialPropertyBlock();
        static float scale => core.val_scale; // 폰 크기
        static float scale2 = 1f; // 수정금지 동물크기
        static Dictionary<WorldObject, List<Vector3>> dic_pos = new Dictionary<WorldObject, List<Vector3>>();
        static List<Pawn> ar_pawn = new List<Pawn>();
        static int n;
        static Vector3 pos;
        static int gapTick = 100;
        static Caravan caravan;
        static caravanData cd;
        static int tryN = 0;
        static Vector3 vel;

        [HarmonyPriority(0)]
        public static bool Prefix(WorldObject __instance)
        {
            if (!(__instance is Caravan)) return true;

            caravan = __instance as Caravan;
            if (!caravan.Faction.IsPlayer) return true;

            
            cd = dataUtility.GetData(caravan);
            
            float averageTileSize = Find.WorldGrid.averageTileSize;
            float transitionPct = ExpandableWorldObjectsUtility.TransitionPct;

            ar_pawn.Clear();
            ar_pawn.AddRange(caravan.PawnsListForReading);
            if (!core.val_showAnimal) ar_pawn.RemoveAll(a => a.RaceProps != null && !a.RaceProps.Humanlike);
            ar_pawn = ar_pawn.OrderByDescending(a => a.RaceProps != null && a.RaceProps.Humanlike).ThenByDescending(a => a.GetStatValueForPawn(StatDefOf.MoveSpeed, a)).ToList();
            if (core.val_limitCount > 0) ar_pawn.RemoveRange(core.val_limitCount, ar_pawn.Count - core.val_limitCount);

            if (cd.prevPos == null) cd.prevPos = new List<Vector3>();

            gapTick = Mathf.Max(1, Mathf.RoundToInt((float)caravan.TicksPerMove / 20f * core.val_space));
            
            n = 0;

            
            tryN = caravan.PawnsListForReading.Count;
            
            
            while (cd.m.Count < caravan.PawnsListForReading.Count && tryN >= 0)
            {
                tryN--;
                cd.m.Add(new Material(ShaderDatabase.WorldOverlayTransparentLit));
            }
            
            for (int i = 0; i < ar_pawn.Count; i++)
            {
                if(i == 0)
                {
                    // leader

                    cd.m[i].renderQueue = WorldMaterials.DynamicObjectRenderQueue;
                    cd.m[i].color = Color.white;
                    Rect rect = ExpandableWorldObjectsUtility.ExpandedIconScreenRect(caravan);
                    rect.size *= scale * 6f;
                    cd.m[i].mainTexture = PortraitsCache.Get(ar_pawn[i], new Vector2(Mathf.Min(512f, rect.width), Mathf.Min(512f, rect.height)), core.getRot(caravan), default, 0.5f);

                    if (core.val_zoomMode != core.en_zoomMode.none && caravan.def.expandingIcon && transitionPct > 0f)
                    {
                        // fade out

                        Color color = cd.m[i].color;
                        float num = 1f - transitionPct;
                        propertyBlock0.SetColor(ShaderPropertyIDs.Color, new Color(color.r, color.g, color.b, color.a * num));
                    }

                    core.DrawQuadTangentialToPlanet(caravan.pather.MovingNow ? ar_pawn[i].thingIDNumber : -1, __instance.DrawPos, scale * 3f * averageTileSize, 0.015f, cd.m[i], counterClockwise: false, useSkyboxLayer: false, propertyBlock0);
                }
                else
                {
                    // followers

                    cd.m[i].renderQueue = WorldMaterials.DynamicObjectRenderQueue;
                    cd.m[i].color = Color.white;
                    Rect rect = ExpandableWorldObjectsUtility.ExpandedIconScreenRect(caravan);

                    if (ar_pawn[i].RaceProps != null && ar_pawn[i].RaceProps.Humanlike)
                    {
                        scale2 = 1f; // 사람 크기
                    }
                    else
                    {
                        scale2 = 0.6f; // 동물 크기
                    }
                    rect.size *= scale * 6f * scale2;
                    
                    //rect.width = Mathf.Min(rect.width, 128);
                    //rect.height = Mathf.Min(rect.height, 128);
                    pos = __instance.DrawPos;
                    vel = Vector3.zero;
                    n = i * gapTick;
                    if(cd.prevPos.Count > 0)
                    {
                        if (cd.prevPos.Count <= n)
                        {
                            n = cd.prevPos.Count - 1;
                        }
                        pos = cd.prevPos[n];

                        vel = cd.prevPos[Mathf.Max(0, n - 3)] - pos;
                    }
                    //pos += new Vector3(0f, 0f, 0.1f * i);

                    cd.m[i].mainTexture = PortraitsCache.Get(ar_pawn[i], new Vector2(Mathf.Min(512f, rect.width), Mathf.Min(512f, rect.height)), core.getRot(vel), default, 0.5f);

                    

                    if (core.val_zoomMode == core.en_zoomMode.vanilla && caravan.def.expandingIcon && transitionPct > 0f)
                    {
                        // fade out
                        core.DrawQuadTangentialToPlanet(caravan.pather.MovingNow ? ar_pawn[i].thingIDNumber : -1, pos, scale * 3f * averageTileSize * scale2, 0.015f, cd.m[i], counterClockwise: false, useSkyboxLayer: false, propertyBlock0);
                    }
                    else
                    {
                        core.DrawQuadTangentialToPlanet(caravan.pather.MovingNow ? ar_pawn[i].thingIDNumber : -1, pos, scale * 3f * averageTileSize * scale2, 0.015f, cd.m[i], counterClockwise: false, useSkyboxLayer: false, propertyBlock);
                    }
                }
                

            }
            n++;
            if (cd.prevPos.Count > n) cd.prevPos.RemoveRange(n, cd.prevPos.Count - n);
            return false;
        }



        
    }






    [HarmonyPatch(typeof(Caravan), "Tick")]
    public class Patch_StatPart_Caravan_Tick
    {

        static caravanData cd;

        [HarmonyPriority(0)]
        public static void Postfix(Caravan __instance)
        {
            cd = dataUtility.GetData(__instance);
            cd.tryAddPrevPos();
        }




    }


    [HarmonyPatch(typeof(WorldDynamicDrawManager), "DrawDynamicWorldObjects")]
    public class Patch_WorldDynamicDrawManager_DrawDynamicWorldObjects
    {

        [HarmonyPriority(0)]
        public static void Postfix(Caravan __instance)
        {
            if (core.val_zoomMode == core.en_zoomMode.vanilla) return;
            if ((ExpandableWorldObjectsUtility.TransitionPct >= 1f))
            {
                foreach (Caravan c in dataUtility.dic_caravan.Keys)
                {
                    if (c == null)
                    {
                        dataUtility.Remove(c);
                        continue;
                    }
                    if (!c.def.expandingIcon)
                    {
                        continue;
                    }
                    c.Draw();

                }
            }




        }
    }




    // 줌아웃 드로우
    
    [HarmonyPatch(typeof(ExpandableWorldObjectsUtility), "ExpandableWorldObjectsOnGUI")]
    public class Patch_ExpandableWorldObjectsUtility_ExpandableWorldObjectsOnGUI
    {
        private static List<WorldObject> tmpWorldObjects = AccessTools.StaticFieldRefAccess<List<WorldObject>>(AccessTools.Field(typeof(ExpandableWorldObjectsUtility), "tmpWorldObjects")).Invoke();
        static List<Pawn> ar_pawn = new List<Pawn>();

        public static bool Prefix()
        {
            if (core.val_zoomMode == core.en_zoomMode.vanilla) return true;
            if (ExpandableWorldObjectsUtility.TransitionPct == 0f)
            {
                return false;
            }
            
            tmpWorldObjects.Clear();
            tmpWorldObjects.AddRange(Find.WorldObjects.AllWorldObjects);
            SortByExpandingIconPriority(tmpWorldObjects);
            WorldTargeter worldTargeter = Find.WorldTargeter;
            List<WorldObject> worldObjectsUnderMouse = null;
            if (worldTargeter.IsTargeting)
            {
                worldObjectsUnderMouse = GenWorldUI.WorldObjectsUnderMouse(UI.MousePositionOnUI);
            }
            for (int i = 0; i < tmpWorldObjects.Count; i++)
            {
                try
                {
                    WorldObject worldObject = tmpWorldObjects[i];
                    if (worldObject.def.expandingIcon && !worldObject.HiddenBehindTerrainNow())
                    {
                        Color expandingIconColor = worldObject.ExpandingIconColor;
                        expandingIconColor.a = ExpandableWorldObjectsUtility.TransitionPct;
                        if (worldTargeter.IsTargetedNow(worldObject, worldObjectsUnderMouse))
                        {
                            float num = GenMath.LerpDouble(-1f, 1f, 0.7f, 1f, Mathf.Sin(Time.time * 8f));
                            expandingIconColor.r *= num;
                            expandingIconColor.g *= num;
                            expandingIconColor.b *= num;
                        }
                        GUI.color = expandingIconColor;
                        Rect rect = ExpandableWorldObjectsUtility.ExpandedIconScreenRect(worldObject);
                        if (worldObject.ExpandingIconFlipHorizontal)
                        {
                            rect.x = rect.xMax;
                            rect.width *= -1f;
                        }

                        if(worldObject is Caravan)
                        {
                            // yayo

                            switch (core.val_zoomMode)
                            {
                                case core.en_zoomMode.bigLeader:
                                    Caravan caravan = worldObject as Caravan;

                                    ar_pawn.Clear();
                                    ar_pawn.AddRange(caravan.PawnsListForReading);
                                    ar_pawn = ar_pawn.OrderByDescending(a => a.RaceProps != null && a.RaceProps.Humanlike).ThenByDescending(a => a.GetStatValueForPawn(StatDefOf.MoveSpeed, a)).ToList();

                                    Pawn p = ar_pawn[0];
                                    float finalScale = 1.5f * core.val_zoomScale;
                                    rect.position -= rect.size * (finalScale - 1f) * 0.5f;
                                    rect.size *= finalScale;
                                    GUI.color = new Color(1f, 1f, 1f, expandingIconColor.a);
                                    Texture t = PortraitsCache.Get(p, new Vector2(512f, 512f), core.getRot(caravan));
                                    Widgets.DrawTextureRotated(rect, t, worldObject.ExpandingIconRotation);
                                    break;
                                case core.en_zoomMode.none:
                                    break;
                                
                            }
                            
                        }
                        else
                        {
                            Widgets.DrawTextureRotated(rect, worldObject.ExpandingIcon, worldObject.ExpandingIconRotation);
                        }
                        
                        
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error while drawing " + tmpWorldObjects[i].ToStringSafe() + ": " + ex);
                }
            }
            tmpWorldObjects.Clear();
            GUI.color = Color.white;
            return false;
        }

        

        private static void SortByExpandingIconPriority(List<WorldObject> worldObjects)
        {
            worldObjects.SortBy(delegate (WorldObject x)
            {
                float num = x.ExpandingIconPriority;
                if (x.Faction != null && x.Faction.IsPlayer)
                {
                    num += 0.001f;
                }
                return num;
            }, (WorldObject x) => x.ID);
        }

        static private Material OverrideMaterialIfNeeded(Material original, Pawn pawn, bool portrait = false)
        {
            
            Material baseMat = ((!portrait && pawn.IsInvisible()) ? InvisibilityMatPool.GetInvisibleMat(original) : original);
            return pawn.Drawer.renderer.graphics.flasher.GetDamagedMat(baseMat);
        }





    }
    

    /*
    [HarmonyPatch(typeof(Map))]
    [HarmonyPatch("ExposeData")]
    public class patch_map_exposeData
    {
        private static void Postfix(Map __instance)
        {
            dataUtility.GetData(__instance).ExposeData();
        }
    }

    [HarmonyPatch(typeof(World))]
    [HarmonyPatch("ExposeData")]
    public class patch_World_exposeData
    {
        private static void Postfix(World __instance)
        {
            dataUtility.GetData(__instance).ExposeData();
        }
    }





    [HarmonyPatch(typeof(DefGenerator), "GenerateImpliedDefs_PreResolve")]
    public class Patch_DefGenerator_GenerateImpliedDefs_PreResolve
    {
        public static void Prefix()
        {
            //yayoCombat.patchDef1();
        }

    }
    */

}
